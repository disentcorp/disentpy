from setuptools import setup

setup(
    name='disent',
    version='0.0.1',
    description='Disent API caller',
    url='git@github.com:rfschubert/ptolemaios-sdk-package.git',
    author='Niels lauritzen',
    author_email='niels.lauritzen@disent.com',
    license='unlicense',
    packages=['disent'],
    zip_safe=False
)